import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Shelfie ISBN Scanner',
  description: 'Scan ISBN barcodes and show Google Books ratings.',
  manifest: '/manifest.json',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
