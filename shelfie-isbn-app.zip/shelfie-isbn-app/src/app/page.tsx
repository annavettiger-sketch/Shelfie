'use client';

import { useEffect, useRef, useState } from 'react';
import { BrowserMultiFormatReader, IScannerControls } from '@zxing/browser';

type Book = {
  title: string;
  authors?: string[];
  averageRating?: number;
  ratingsCount?: number;
  description?: string;
  thumbnail?: string;
  infoLink?: string;
};

function cleanIsbn(value: string) {
  return value.replace(/[^0-9Xx]/g, '').trim();
}

export default function Home() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const controlsRef = useRef<IScannerControls | null>(null);

  const [isbn, setIsbn] = useState('');
  const [book, setBook] = useState<Book | null>(null);
  const [savedBooks, setSavedBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const raw = localStorage.getItem('shelfie-books');
    if (raw) setSavedBooks(JSON.parse(raw));
  }, []);

  useEffect(() => {
    localStorage.setItem('shelfie-books', JSON.stringify(savedBooks));
  }, [savedBooks]);

  async function startScanner() {
    setMessage('');
    setScanning(true);
    setBook(null);

    try {
      const reader = new BrowserMultiFormatReader();
      const controls = await reader.decodeFromVideoDevice(
        undefined,
        videoRef.current!,
        async (result) => {
          if (result) {
            const code = cleanIsbn(result.getText());
            setIsbn(code);
            stopScanner();
            await searchBook(code);
          }
        }
      );
      controlsRef.current = controls;
    } catch (error) {
      setScanning(false);
      setMessage('Kamera konnte nicht gestartet werden. Erlaube den Kamerazugriff und nutze Safari/Chrome über HTTPS.');
    }
  }

  function stopScanner() {
    controlsRef.current?.stop();
    controlsRef.current = null;
    setScanning(false);
  }

  async function searchBook(code = isbn) {
    const cleaned = cleanIsbn(code);
    if (!cleaned) {
      setMessage('Bitte eine ISBN eingeben oder einen Barcode scannen.');
      return;
    }

    setLoading(true);
    setMessage('');
    setBook(null);

    try {
      const res = await fetch(`https://www.googleapis.com/books/v1/volumes?q=isbn:${encodeURIComponent(cleaned)}`);
      const data = await res.json();

      if (!data.items?.length) {
        setMessage('Kein Buch bei Google Books gefunden. Probiere die ISBN manuell oder scanne nochmals.');
        return;
      }

      const volume = data.items[0].volumeInfo;
      setBook({
        title: volume.title ?? 'Unbekannter Titel',
        authors: volume.authors,
        averageRating: volume.averageRating,
        ratingsCount: volume.ratingsCount,
        description: volume.description,
        thumbnail: volume.imageLinks?.thumbnail?.replace('http://', 'https://'),
        infoLink: volume.infoLink,
      });
    } catch (error) {
      setMessage('Suche fehlgeschlagen. Prüfe deine Internetverbindung.');
    } finally {
      setLoading(false);
    }
  }

  function saveCurrentBook() {
    if (!book) return;
    setSavedBooks((prev) => {
      if (prev.some((b) => b.title === book.title && b.authors?.join(',') === book.authors?.join(','))) return prev;
      return [book, ...prev];
    });
  }

  function clearSavedBooks() {
    setSavedBooks([]);
  }

  return (
    <main>
      <h1>Shelfie</h1>
      <p className="small">Scanne den ISBN-Barcode eines Buches und sieh direkt die Bewertung aus Google Books.</p>

      <section className="card">
        <div className="row">
          <button onClick={scanning ? stopScanner : startScanner}>{scanning ? 'Scan stoppen' : 'Buch scannen'}</button>
          <button className="secondary" onClick={() => searchBook()} disabled={loading}>ISBN suchen</button>
        </div>

        <video ref={videoRef} muted playsInline />

        <p className="small">Oder ISBN manuell eingeben:</p>
        <input
          value={isbn}
          onChange={(e) => setIsbn(e.target.value)}
          placeholder="z.B. 9780143127741"
          inputMode="numeric"
        />

        {loading && <p>Suche Buch...</p>}
        {message && <p className="error">{message}</p>}
      </section>

      {book && (
        <section className="card book">
          {book.thumbnail ? <img className="cover" src={book.thumbnail} alt="Buchcover" /> : <div className="cover" />}
          <div className="meta">
            <h2>{book.title}</h2>
            <p>{book.authors?.join(', ') ?? 'Autor:in unbekannt'}</p>
            <p className="rating">
              {book.averageRating ? `⭐ ${book.averageRating} / 5` : 'Keine Bewertung'}
              {book.ratingsCount ? ` · ${book.ratingsCount.toLocaleString('de-CH')} Bewertungen` : ''}
            </p>
            {book.description && <p className="small">{book.description.slice(0, 220)}{book.description.length > 220 ? '...' : ''}</p>}
            <div className="row">
              <button onClick={saveCurrentBook}>Merken</button>
              {book.infoLink && <a href={book.infoLink} target="_blank" rel="noreferrer">Google Books öffnen</a>}
            </div>
          </div>
        </section>
      )}

      <section className="card">
        <div className="row">
          <h2 style={{ margin: 0, flex: 1 }}>Merkliste</h2>
          <button className="secondary" onClick={clearSavedBooks} disabled={!savedBooks.length}>Leeren</button>
        </div>
        {!savedBooks.length && <p className="small">Noch keine Bücher gespeichert.</p>}
        {savedBooks.map((saved, index) => (
          <div key={`${saved.title}-${index}`} className="saved-item">
            <strong>{saved.title}</strong><br />
            <span className="small">{saved.authors?.join(', ') ?? 'Autor:in unbekannt'} · {saved.averageRating ? `⭐ ${saved.averageRating}` : 'Keine Bewertung'}</span>
          </div>
        ))}
      </section>
    </main>
  );
}
